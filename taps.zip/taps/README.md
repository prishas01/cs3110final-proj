# cs3110-finalproject

Hello! Welcome to TAPS!
This is our data management system for songs, and final project for CS 3110.

Authors:
Prisha Singhal (ps863)
Shefali Awasthi (sa867)
Teg Singh (ts647)
Anjali Kesari (ak2239)


Acknowledgements:

The Million Song Dataset: Thierry Bertin-Mahieux, Daniel P.W. Ellis, Brian Whitman, and Paul Lamere. The Million Song Dataset. In Proceedings of the 12th International Society for Music Information Retrieval Conference (ISMIR 2011), 2011.

Database_Management_System: References code from past project by Natalie Isak, Lillian Joyce, and Brett Schlesinger