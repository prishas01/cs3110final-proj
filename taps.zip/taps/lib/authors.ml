(* TODO: set values for time worked on project. Order: Shefali, Prisha, Teg,
   Anjali*)
let hours_worked = [ 20; 20; 20; 20 ]
